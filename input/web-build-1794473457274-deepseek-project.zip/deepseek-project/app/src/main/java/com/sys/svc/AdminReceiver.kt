package com.sys.svc

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()