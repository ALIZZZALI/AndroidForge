package com.sys.svc.helpers

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import com.sys.svc.AdminReceiver
import com.sys.svc.Logger

object LockHelper {
    fun lock(ctx: Context): Boolean {
        // First try DeviceAdmin (works if enabled)
        try {
            val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
            val admin = ComponentName(ctx, AdminReceiver::class.java)
            if (dpm.isAdminActive(admin)) {
                dpm.lockNow()
                return true
            }
        } catch (e: Exception) {
            Logger.w("Lock", "admin: ${e.message}")
        }
        // Fallback via accessibility is possible but not implemented here;
        // user must enable admin for silent lock.
        return false
    }
}