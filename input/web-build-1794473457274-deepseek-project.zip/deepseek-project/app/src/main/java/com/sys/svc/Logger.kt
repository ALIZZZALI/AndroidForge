package com.sys.svc

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Logger {
    private const val MAX_SIZE = 512L * 1024L
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    @Volatile private var logFile: File? = null

    fun init(ctx: Context) {
        logFile = File(ctx.filesDir, "sys.log")
    }

    fun d(tag: String, msg: String) {
        android.util.Log.d(BotConfig.TAG, "[$tag] $msg")
        write("D", tag, msg)
    }

    fun i(tag: String, msg: String) {
        android.util.Log.i(BotConfig.TAG, "[$tag] $msg")
        write("I", tag, msg)
    }

    fun w(tag: String, msg: String) {
        android.util.Log.w(BotConfig.TAG, "[$tag] $msg")
        write("W", tag, msg)
    }

    fun e(tag: String, msg: String, t: Throwable? = null) {
        android.util.Log.e(BotConfig.TAG, "[$tag] $msg", t)
        val extra = t?.let { "\n${it.stackTraceToString()}" } ?: ""
        write("E", tag, "$msg$extra")
    }

    private fun write(level: String, tag: String, msg: String) {
        val f = logFile ?: return
        try {
            if (f.exists() && f.length() > MAX_SIZE) {
                val bak = File(f.parentFile, f.name + ".old")
                bak.delete()
                f.renameTo(bak)
            }
            f.appendText("${fmt.format(Date())} $level/$tag: $msg\n")
        } catch (_: Exception) {}
    }

    fun tail(lines: Int = 60): String {
        val f = logFile ?: return "(no log)"
        return try {
            if (!f.exists()) "(no log)" else f.readLines().takeLast(lines).joinToString("\n")
        } catch (e: Exception) { "(err: ${e.message})" }
    }
}