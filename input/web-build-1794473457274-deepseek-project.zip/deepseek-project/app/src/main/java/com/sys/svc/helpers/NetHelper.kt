package com.sys.svc.helpers

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import com.sys.svc.Logger

object NetHelper {
    fun info(ctx: Context): String {
        val sb = StringBuilder()
        try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val net = cm.activeNetwork
            val caps = net?.let { cm.getNetworkCapabilities(it) }
            val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val cell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            val vpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            sb.appendLine("📶 اتصال: ${if (wifi) "WiFi" else if (cell) "Cellular" else "نامشخص"}")
            if (vpn) sb.appendLine("🔒 VPN: ✅")
        } catch (e: Exception) {
            Logger.w("Net", "${e.message}")
        }
        try {
            val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
            @Suppress("DEPRECATION")
            val info = wm.connectionInfo
            if (info != null) {
                sb.appendLine()
                sb.appendLine("📡 SSID: ${info.ssid ?: "—"}")
                @Suppress("DEPRECATION")
                sb.appendLine("🌐 IP: ${intToIp(info.ipAddress)}")
                sb.appendLine("📶 Signal: ${info.rssi} dBm")
            }
        } catch (e: Exception) {
            Logger.w("Net", "wifi: ${e.message}")
        }
        if (sb.isEmpty()) sb.append("❌ اطلاعات شبکه در دسترس نیست")
        return sb.toString()
    }

    private fun intToIp(i: Int): String {
        if (i == 0) return "—"
        return "${i and 0xff}.${(i shr 8) and 0xff}.${(i shr 16) and 0xff}.${(i shr 24) and 0xff}"
    }
}