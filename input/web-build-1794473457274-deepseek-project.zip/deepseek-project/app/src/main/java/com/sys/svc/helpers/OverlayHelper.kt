package com.sys.svc.helpers

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.sys.svc.Logger

object OverlayHelper {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var currentView: LinearLayout? = null

    fun canDrawOverlays(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(ctx) else true

    fun showText(ctx: Context, text: String, durationMs: Long = 15_000L) {
        if (text.isBlank()) return
        if (!canDrawOverlays(ctx)) {
            Logger.w("Overlay", "no permission")
            return
        }
        handler.post {
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val view = LinearLayout(ctx).apply {
                    setBackgroundColor(Color.argb(220, 10, 10, 10))
                    orientation = LinearLayout.VERTICAL
                    setPadding(60, 40, 60, 40)
                }
                val tv = TextView(ctx).apply {
                    this.text = text
                    setTextColor(Color.WHITE)
                    textSize = 22f
                    gravity = Gravity.CENTER
                    maxWidth = 1000
                }
                view.addView(tv)
                val type = if (Build.VERSION.SDK_INT >= 26)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.CENTER }
                wm.addView(view, lp)
                currentView = view
                handler.postDelayed({
                    try { wm.removeView(view) } catch (_: Exception) {}
                    if (currentView === view) currentView = null
                }, durationMs)
            } catch (e: Exception) {
                Logger.e("Overlay", "show", e)
            }
        }
    }
}