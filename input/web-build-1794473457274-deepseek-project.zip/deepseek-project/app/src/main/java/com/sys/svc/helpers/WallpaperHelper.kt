package com.sys.svc.helpers

import android.app.WallpaperManager
import android.content.Context
import com.sys.svc.Logger
import java.io.File

object WallpaperHelper {
    fun set(ctx: Context, file: File): Boolean {
        return try {
            val wm = WallpaperManager.getInstance(ctx)
            file.inputStream().use { wm.setStream(it) }
            Logger.i("Wp", "set: ${file.name}")
            true
        } catch (e: Exception) {
            Logger.e("Wp", "set", e)
            false
        }
    }
}