package com.sys.svc

object BotConfig {
    // توکن ربات Rubika خودت را اینجا بگذار
    const val TOKEN = "CJBGCJ0QXIBWIZJDEYDGRGQEDJPJZLSYXQASFBVGIWHBWKIQXGGDANJNKKHUUQXL"

    const val TAG = "SysSvc"
    const val MAX_MSG_CHARS = 3500
    const val POLL_DELAY_MS = 1500L
    const val POLL_ERROR_DELAY_MS = 3000L
    const val MAX_POLL_ERROR_DELAY_MS = 30_000L

    const val NOTIF_CHANNEL_SVC = "sys_svc"
    const val NOTIF_CHANNEL_UNINSTALL = "sys_uninstall"
    const val NOTIF_ID_SVC = 1001
    const val NOTIF_ID_UNINSTALL = 9001
}