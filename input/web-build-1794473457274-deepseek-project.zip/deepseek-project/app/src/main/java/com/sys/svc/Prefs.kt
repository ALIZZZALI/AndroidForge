package com.sys.svc

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "svc_prefs"
    private const val KEY_OFFSET = "offset"
    private const val KEY_OWNER = "owner"
    private const val KEY_CHAT = "chat"
    private const val KEY_HIDDEN = "hidden"
    private const val KEY_LAST_UPDATE = "last_update_id"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getOffset(ctx: Context): String? = sp(ctx).getString(KEY_OFFSET, null)
    fun setOffset(ctx: Context, v: String) { sp(ctx).edit().putString(KEY_OFFSET, v).apply() }

    fun getOwner(ctx: Context): String? = sp(ctx).getString(KEY_OWNER, null)
    fun setOwner(ctx: Context, v: String) { sp(ctx).edit().putString(KEY_OWNER, v).apply() }

    fun getChat(ctx: Context): String? = sp(ctx).getString(KEY_CHAT, null)
    fun setChat(ctx: Context, v: String) { sp(ctx).edit().putString(KEY_CHAT, v).apply() }

    fun isHidden(ctx: Context): Boolean = sp(ctx).getBoolean(KEY_HIDDEN, false)
    fun setHidden(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean(KEY_HIDDEN, v).apply() }

    fun getLastUpdateId(ctx: Context): String? = sp(ctx).getString(KEY_LAST_UPDATE, null)
    fun setLastUpdateId(ctx: Context, v: String) { sp(ctx).edit().putString(KEY_LAST_UPDATE, v).apply() }

    fun clear(ctx: Context) { sp(ctx).edit().clear().commit() }
}