package com.sys.svc.helpers

import android.content.Context
import android.service.notification.NotificationListenerService

object NotificationHelper {
    fun list(ctx: Context): String {
        return "🔔 لیست نوتیف‌ها نیاز به NotificationListenerService دارد.\n" +
               "برای فعال‌سازی: Settings → Notifications → Device & app notifications → SysSvc\n" +
               "(در این نسخه پیاده‌سازی نشده — از Accessibility استفاده می‌شود.)"
    }
}