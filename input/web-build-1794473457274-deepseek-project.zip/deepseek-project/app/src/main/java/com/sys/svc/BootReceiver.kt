package com.sys.svc

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON" &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        Logger.init(ctx)
        Logger.i("Boot", "received: $action")
        try { BotService.start(ctx) } catch (e: Exception) {
            Logger.e("Boot", "start failed", e)
        }
    }
}