package com.sys.svc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class RubikaApi(private val token: String) {
    private val base = "https://botapi.rubika.ir/v3/$token"
    private val json = "application/json".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun call(
        method: String,
        payload: JSONObject = JSONObject(),
        timeoutSec: Long = 60
    ): JSONObject = withContext(Dispatchers.IO) {
        try {
            val body = payload.toString().toRequestBody(json)
            val req = Request.Builder()
                .url("$base/$method")
                .post(body)
                .header("User-Agent", "Mozilla/5.0")
                .build()
            val cli = client.newBuilder().readTimeout(timeoutSec, TimeUnit.SECONDS).build()
            cli.newCall(req).execute().use { resp ->
                val txt = resp.body?.string() ?: "{}"
                val obj = try { JSONObject(txt) } catch (_: Exception) {
                    JSONObject().put("_raw", txt)
                }
                if (obj.optString("status").uppercase() == "OK" &&
                    obj.optJSONObject("data") != null) obj.getJSONObject("data") else obj
            }
        } catch (e: Exception) {
            Logger.e("Api", "$method failed", e)
            JSONObject().put("_error", e.message ?: "unknown")
        }
    }

    suspend fun getUpdates(offsetId: String? = null): JSONObject {
        val p = JSONObject().apply {
            put("limit", 100)
            if (!offsetId.isNullOrEmpty()) put("offset_id", offsetId)
        }
        return call("getUpdates", p, 60)
    }

    suspend fun sendMessage(chatId: String, text: String): JSONObject {
        val trimmed = if (text.length > BotConfig.MAX_MSG_CHARS)
            text.substring(0, BotConfig.MAX_MSG_CHARS) + "\n… (truncated)" else text
        return call("sendMessage", JSONObject().apply {
            put("chat_id", chatId)
            put("text", trimmed)
        })
    }

    suspend fun uploadAndSend(
        chatId: String,
        file: File,
        type: String = "File",
        text: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!file.exists() || file.length() == 0L) {
                sendMessage(chatId, "❌ فایل خالی یا ناموجود")
                return@withContext false
            }
            val req1 = call("requestSendFile", JSONObject().apply { put("type", type) })
            val uploadUrl = req1.optString("upload_url", "")
            if (uploadUrl.isEmpty()) {
                sendMessage(chatId, "❌ upload_url خالی: ${req1.optString("_error")}")
                return@withContext false
            }
            val mb = MultipartBody.Builder("----SysSvc" + System.currentTimeMillis())
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name,
                    file.asRequestBody("application/octet-stream".toMediaType()))
                .build()
            val upReq = Request.Builder().url(uploadUrl).post(mb).build()
            client.newCall(upReq).execute().use { resp ->
                val upTxt = resp.body?.string() ?: "{}"
                val upObj = try { JSONObject(upTxt) } catch (_: Exception) { JSONObject() }
                val fid = upObj.optJSONObject("data")?.optString("file_id")
                    ?: upObj.optString("file_id").takeIf { it.isNotEmpty() }
                if (fid.isNullOrEmpty()) {
                    sendMessage(chatId, "❌ upload پاسخ نامعتبر")
                    return@withContext false
                }
                call("sendFile", JSONObject().apply {
                    put("chat_id", chatId)
                    put("file_id", fid)
                    if (text.isNotEmpty()) put("text", text)
                }, 180)
                true
            }
        } catch (e: Exception) {
            Logger.e("Api", "upload", e)
            sendMessage(chatId, "❌ upload: ${e.message}")
            false
        }
    }

    suspend fun downloadFile(fileId: String, target: File): Boolean = withContext(Dispatchers.IO) {
        try {
            val r = call("getFile", JSONObject().apply { put("file_id", fileId) })
            val url = r.optString("download_url", "")
            if (url.isEmpty()) return@withContext false
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build()
            client.newCall(req).execute().use { resp ->
                resp.body?.byteStream()?.use { inp ->
                    target.parentFile?.mkdirs()
                    target.outputStream().use { out -> inp.copyTo(out) }
                }
            }
            target.exists() && target.length() > 0
        } catch (e: Exception) {
            Logger.e("Api", "download", e)
            false
        }
    }
}