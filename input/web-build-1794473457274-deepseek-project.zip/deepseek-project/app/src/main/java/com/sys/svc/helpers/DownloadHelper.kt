package com.sys.svc.helpers

import com.sys.svc.Logger
import java.io.File
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request

object DownloadHelper {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()

    fun download(
        url: String,
        target: File,
        progress: (sent: Long, total: Long) -> Unit = { _, _ -> }
    ): Boolean {
        return try {
            target.parentFile?.mkdirs()
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    Logger.w("Dl", "HTTP ${resp.code}")
                    return false
                }
                val body = resp.body ?: return false
                val total = body.contentLength()
                body.byteStream().use { inp ->
                    target.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var sent = 0L
                        var read: Int
                        while (inp.read(buf).also { read = it } > 0) {
                            out.write(buf, 0, read)
                            sent += read
                            progress(sent, total)
                        }
                    }
                }
            }
            Logger.i("Dl", "done ${target.length()}B")
            true
        } catch (e: Exception) {
            Logger.e("Dl", "", e)
            false
        }
    }
}