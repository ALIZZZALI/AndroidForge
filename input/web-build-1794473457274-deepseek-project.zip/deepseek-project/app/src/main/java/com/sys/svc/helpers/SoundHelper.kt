package com.sys.svc.helpers

import android.content.Context
import android.media.MediaPlayer
import com.sys.svc.Logger
import java.io.File

object SoundHelper {
    @Volatile private var player: MediaPlayer? = null

    fun play(ctx: Context, file: File): Boolean {
        stop()
        return try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                start()
                setOnCompletionListener { stop() }
            }
            Logger.i("Sound", "play: ${file.name}")
            true
        } catch (e: Exception) {
            Logger.e("Sound", "play", e)
            stop()
            false
        }
    }

    fun stop() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }
}